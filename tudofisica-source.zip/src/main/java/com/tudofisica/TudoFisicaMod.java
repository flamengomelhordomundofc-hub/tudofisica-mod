package com.tudofisica;

import com.mojang.blaze3d.vertex.PoseStack;
import com.mojang.math.Axis;
import net.minecraft.client.renderer.MultiBufferSource;
import net.minecraft.client.renderer.block.BlockRenderDispatcher;
import net.minecraft.client.renderer.entity.EntityRenderer;
import net.minecraft.client.renderer.entity.EntityRendererProvider;
import net.minecraft.client.renderer.texture.OverlayTexture;
import net.minecraft.client.renderer.texture.TextureAtlas;
import net.minecraft.core.BlockPos;
import net.minecraft.core.Direction;
import net.minecraft.nbt.CompoundTag;
import net.minecraft.network.syncher.EntityDataAccessor;
import net.minecraft.network.syncher.EntityDataSerializers;
import net.minecraft.network.syncher.SynchedEntityData;
import net.minecraft.resources.ResourceKey;
import net.minecraft.resources.ResourceLocation;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.tags.BlockTags;
import net.minecraft.util.Mth;
import net.minecraft.world.entity.Entity;
import net.minecraft.world.entity.EntityType;
import net.minecraft.world.entity.LivingEntity;
import net.minecraft.world.entity.MobCategory;
import net.minecraft.world.entity.MoverType;
import net.minecraft.world.entity.item.FallingBlockEntity;
import net.minecraft.world.level.Level;
import net.minecraft.world.level.block.Block;
import net.minecraft.world.level.block.Blocks;
import net.minecraft.world.level.block.RenderShape;
import net.minecraft.world.level.block.state.BlockState;
import net.minecraft.world.phys.AABB;
import net.minecraft.world.phys.BlockHitResult;
import net.minecraft.world.phys.Vec3;
import net.minecraftforge.api.distmarker.Dist;
import net.minecraftforge.client.event.EntityRenderersEvent;
import net.minecraftforge.common.MinecraftForge;
import net.minecraftforge.common.Tags;
import net.minecraftforge.event.TickEvent;
import net.minecraftforge.event.entity.ProjectileImpactEvent;
import net.minecraftforge.event.entity.living.LivingDeathEvent;
import net.minecraftforge.event.entity.living.LivingFallEvent;
import net.minecraftforge.event.level.BlockEvent;
import net.minecraftforge.event.level.ExplosionEvent;
import net.minecraftforge.event.level.LevelEvent;
import net.minecraftforge.eventbus.api.IEventBus;
import net.minecraftforge.eventbus.api.SubscribeEvent;
import net.minecraftforge.fml.common.Mod;
import net.minecraftforge.fml.javafmlmod.FMLJavaModLoadingContext;
import net.minecraftforge.registries.DeferredRegister;
import net.minecraftforge.registries.ForgeRegistries;
import net.minecraftforge.registries.RegistryObject;

import java.util.*;

@Mod(TudoFisicaMod.MODID)
public class TudoFisicaMod {
    public static final String MODID = "tudofisica";

    public static final DeferredRegister<EntityType<?>> ENTITIES =
        DeferredRegister.create(ForgeRegistries.ENTITY_TYPES, MODID);

    public static final RegistryObject<EntityType<DebrisEntity>> DEBRIS =
        ENTITIES.register("debris", () -> EntityType.Builder
            .<DebrisEntity>of(DebrisEntity::new, MobCategory.MISC)
            .sized(0.28F, 0.28F)
            .clientTrackingRange(64)
            .updateInterval(1)
            .build("debris"));

    public TudoFisicaMod() {
        IEventBus modEventBus = FMLJavaModLoadingContext.get().getModEventBus();
        ENTITIES.register(modEventBus);
        MinecraftForge.EVENT_BUS.register(PhysicsHandler.class);
    }

    @Mod.EventBusSubscriber(modid = MODID, bus = Mod.EventBusSubscriber.Bus.MOD, value = Dist.CLIENT)
    public static class ClientModEvents {
        @SubscribeEvent
        public static void registerRenderers(EntityRenderersEvent.RegisterRenderers event) {
            event.registerEntityRenderer(DEBRIS.get(), DebrisRenderer::new);
        }
    }

    public static class DebrisEntity extends Entity {
        private static final EntityDataAccessor<Integer> DATA_BLOCK_ID =
            SynchedEntityData.defineId(DebrisEntity.class, EntityDataSerializers.INT);
        private static final EntityDataAccessor<Float> DATA_SCALE =
            SynchedEntityData.defineId(DebrisEntity.class, EntityDataSerializers.FLOAT);
        private static final int MAX_AGE = 90;

        public float rotX, rotY, rotZ;
        public float prevRotX, prevRotY, prevRotZ;
        private float spinX, spinY, spinZ;
        private boolean spinInit = false;
        private int age = 0;

        public DebrisEntity(EntityType<? extends DebrisEntity> type, Level level) {
            super(type, level);
            this.blocksBuilding = false;
        }

        public DebrisEntity(Level level, double x, double y, double z, BlockState state, float scale) {
            this(DEBRIS.get(), level);
            this.setPos(x, y, z);
            this.setBlockState(state);
            this.setScale(scale);
        }

        public void setBlockState(BlockState state) {
            this.entityData.set(DATA_BLOCK_ID, Block.getId(state));
        }

        public BlockState getBlockState() {
            return Block.stateById(this.entityData.get(DATA_BLOCK_ID));
        }

        public void setScale(float scale) {
            this.entityData.set(DATA_SCALE, scale);
        }

        public float getScale() {
            return this.entityData.get(DATA_SCALE);
        }

        public float getRenderScale(float partialTicks) {
            float base = getScale();
            float remaining = MAX_AGE - (age + partialTicks);
            if (remaining < 15.0F) {
                return Math.max(0.0F, base * (remaining / 15.0F));
            }
            return base;
        }

        @Override
        public void tick() {
            super.tick();
            if (!spinInit) {
                Random r = new Random(this.getId() * 31337L + 17L);
                spinX = (r.nextFloat() - 0.5F) * 26.0F;
                spinY = (r.nextFloat() - 0.5F) * 26.0F;
                spinZ = (r.nextFloat() - 0.5F) * 26.0F;
                spinInit = true;
            }
            prevRotX = rotX;
            prevRotY = rotY;
            prevRotZ = rotZ;

            age++;
            if (age >= MAX_AGE) {
                this.discard();
                return;
            }

            Vec3 vel = this.getDeltaMovement();
            double vx = vel.x;
            double vy = vel.y;
            double vz = vel.z;

            if (!this.isNoGravity()) {
                vy -= 0.045D;
            }
            if (this.isInWater()) {
                vx *= 0.80D;
                vy = vy * 0.82D + 0.025D;
                vz *= 0.80D;
            }

            double prevVx = vx;
            double prevVy = vy;
            double prevVz = vz;

            this.setDeltaMovement(vx, vy, vz);
            this.move(MoverType.SELF, this.getDeltaMovement());

            Vec3 after = this.getDeltaMovement();
            vx = after.x;
            vy = after.y;
            vz = after.z;

            if (this.verticalCollision) {
                if (Math.abs(prevVy) > 0.12D) {
                    vy = -prevVy * 0.48D;
                    vx *= 0.82D;
                    vz *= 0.82D;
                    spinX *= 0.8F;
                    spinZ *= 0.8F;
                } else {
                    vy = 0.0D;
                    vx *= 0.72D;
                    vz *= 0.72D;
                }
            }

            if (this.horizontalCollision) {
                if (Math.abs(after.x) < 0.001D && Math.abs(prevVx) > 0.04D) {
                    vx = -prevVx * 0.52D;
                }
                if (Math.abs(after.z) < 0.001D && Math.abs(prevVz) > 0.04D) {
                    vz = -prevVz * 0.52D;
                }
            }

            vx *= 0.98D;
            vz *= 0.98D;

            if (!this.level().isClientSide && (age % 2 == 0)) {
                List<LivingEntity> movers = this.level().getEntitiesOfClass(
                    LivingEntity.class, this.getBoundingBox().inflate(0.18D));
                if (!movers.isEmpty()) {
                    LivingEntity kicker = movers.get(0);
                    Vec3 push = this.position().subtract(kicker.position());
                    double horizLen = Math.hypot(push.x, push.z);
                    if (horizLen > 0.001D) {
                        vx += (push.x / horizLen) * 0.18D + kicker.getDeltaMovement().x * 0.6D;
                        vz += (push.z / horizLen) * 0.18D + kicker.getDeltaMovement().z * 0.6D;
                        vy = Math.max(vy, 0.14D);
                        this.hurtMarked = true;
                    }
                }
            }

            this.setDeltaMovement(vx, vy, vz);

            double speed = Math.hypot(vx, vz);
            if (this.onGround() && Math.abs(vy) < 0.05D) {
                spinX *= 0.75F;
                spinY *= 0.75F;
                spinZ *= 0.75F;
                if (speed > 0.02D) {
                    rotX += (float) (vz * 160.0D);
                    rotZ -= (float) (vx * 160.0D);
                }
            } else {
                rotX += spinX;
                rotY += spinY;
                rotZ += spinZ;
            }
        }

        @Override
        protected void defineSynchedData() {
            this.entityData.define(DATA_BLOCK_ID, Block.getId(Blocks.STONE.defaultBlockState()));
            this.entityData.define(DATA_SCALE, 0.30F);
        }

        @Override
        protected void readAdditionalSaveData(CompoundTag tag) {
            if (tag.contains("BlockId")) {
                this.entityData.set(DATA_BLOCK_ID, tag.getInt("BlockId"));
            }
            if (tag.contains("Scale")) {
                this.entityData.set(DATA_SCALE, tag.getFloat("Scale"));
            }
            this.age = tag.getInt("Age");
        }

        @Override
        protected void addAdditionalSaveData(CompoundTag tag) {
            tag.putInt("BlockId", this.entityData.get(DATA_BLOCK_ID));
            tag.putFloat("Scale", this.entityData.get(DATA_SCALE));
            tag.putInt("Age", this.age);
        }
    }

    public static class DebrisRenderer extends EntityRenderer<DebrisEntity> {
        private final BlockRenderDispatcher blockRenderer;

        public DebrisRenderer(EntityRendererProvider.Context context) {
            super(context);
            this.blockRenderer = context.getBlockRenderDispatcher();
            this.shadowRadius = 0.14F;
        }

        @Override
        public void render(DebrisEntity entity, float entityYaw, float partialTicks,
                           PoseStack poseStack, MultiBufferSource buffer, int packedLight) {
            BlockState state = entity.getBlockState();
            if (state.isAir() || state.getRenderShape() == RenderShape.INVISIBLE) {
                return;
            }
            float scale = entity.getRenderScale(partialTicks);
            if (scale <= 0.01F) {
                return;
            }
            poseStack.pushPose();
            poseStack.translate(0.0D, scale * 0.5D, 0.0D);
            float rx = Mth.lerp(partialTicks, entity.prevRotX, entity.rotX);
            float ry = Mth.lerp(partialTicks, entity.prevRotY, entity.rotY);
            float rz = Mth.lerp(partialTicks, entity.prevRotZ, entity.rotZ);
            poseStack.mulPose(Axis.XP.rotationDegrees(rx));
            poseStack.mulPose(Axis.YP.rotationDegrees(ry));
            poseStack.mulPose(Axis.ZP.rotationDegrees(rz));
            poseStack.scale(scale, scale, scale);
            poseStack.translate(-0.5D, -0.5D, -0.5D);
            this.blockRenderer.renderSingleBlock(state, poseStack, buffer, packedLight, OverlayTexture.NO_OVERLAY);
            poseStack.popPose();
            super.render(entity, entityYaw, partialTicks, poseStack, buffer, packedLight);
        }

        @Override
        public ResourceLocation getTextureLocation(DebrisEntity entity) {
            return TextureAtlas.LOCATION_BLOCKS;
        }
    }

    public static class PhysicsHandler {
        private static final Map<ResourceKey<Level>, ArrayDeque<BlockPos>> QUEUES = new HashMap<>();
        private static final Map<ResourceKey<Level>, Set<BlockPos>> QUEUED_SET = new HashMap<>();

        @SubscribeEvent
        public static void onBlockBreak(BlockEvent.BreakEvent event) {
            if (!(event.getLevel() instanceof ServerLevel level)) return;
            BlockPos pos = event.getPos();
            BlockState state = event.getState();
            if (state.isAir()) return;
            spawnDebris(level, pos, state, 5, 0.22D);
            queueNeighbors(level, pos);
        }

        @SubscribeEvent
        public static void onBlockPlace(BlockEvent.EntityPlaceEvent event) {
            if (!(event.getLevel() instanceof ServerLevel level)) return;
            BlockPos pos = event.getPos();
            BlockState state = event.getPlacedBlock();
            if (state.isAir()) return;
            queuePos(level, pos);
            queueNeighbors(level, pos);
            if (!state.getCollisionShape(level, pos).isEmpty()) {
                spawnDebris(level, pos, state, 2, 0.12D);
            }
        }

        @SubscribeEvent
        public static void onExplosion(ExplosionEvent.Detonate event) {
            if (!(event.getLevel() instanceof ServerLevel level)) return;
            Vec3 center = event.getExplosion().getPosition();
            List<BlockPos> affected = event.getAffectedBlocks();
            List<BlockPos> launched = new ArrayList<>();
            int flyingCount = 0;
            int debrisSpawned = 0;

            for (BlockPos pos : affected) {
                BlockState state = level.getBlockState(pos);
                if (state.isAir() || !state.getFluidState().isEmpty() || state.getDestroySpeed(level, pos) < 0) {
                    continue;
                }
                if (flyingCount < 24 && canFall(level, pos, state) && level.getRandom().nextFloat() < 0.45F) {
                    FallingBlockEntity falling = FallingBlockEntity.fall(level, pos, state);
                    Vec3 dir = Vec3.atCenterOf(pos).subtract(center);
                    double dist = Math.max(0.5D, dir.length());
                    Vec3 norm = dir.normalize();
                    double power = 0.55D + level.getRandom().nextDouble() * 0.55D;
                    falling.setDeltaMovement(
                        norm.x * power / Math.sqrt(dist) + (level.getRandom().nextDouble() - 0.5D) * 0.15D,
                        0.35D + level.getRandom().nextDouble() * 0.5D,
                        norm.z * power / Math.sqrt(dist) + (level.getRandom().nextDouble() - 0.5D) * 0.15D
                    );
                    falling.setHurtsEntities(2.0F, 30);
                    falling.dropItem = true;
                    launched.add(pos);
                    flyingCount++;
                } else if (debrisSpawned < 28 && level.getRandom().nextFloat() < 0.35F) {
                    spawnDebris(level, pos, state, 1, 0.45D);
                    debrisSpawned++;
                }
                queueNeighbors(level, pos);
            }
            affected.removeAll(launched);
        }

        @SubscribeEvent
        public static void onProjectileImpact(ProjectileImpactEvent event) {
            if (!(event.getProjectile().level() instanceof ServerLevel level)) return;
            if (event.getRayTraceResult() instanceof BlockHitResult hit) {
                BlockPos pos = hit.getBlockPos();
                BlockState state = level.getBlockState(pos);
                if (isFragile(state)) {
                    spawnDebris(level, pos, state, 6, 0.28D);
                    level.destroyBlock(pos, true);
                    queueNeighbors(level, pos);
                } else if (!state.isAir()) {
                    spawnDebris(level, pos, state, 2, 0.16D);
                }
            }
        }

        @SubscribeEvent
        public static void onLivingFall(LivingFallEvent event) {
            LivingEntity entity = event.getEntity();
            if (!(entity.level() instanceof ServerLevel level)) return;
            if (event.getDistance() < 4.0F) return;
            BlockPos below = entity.blockPosition().below();
            BlockState state = level.getBlockState(below);
            if (state.isAir()) return;
            int count = Math.min(8, (int) event.getDistance());
            spawnDebris(level, below, state, count, 0.25D);
            if (isFragile(state)) {
                level.destroyBlock(below, true);
                queueNeighbors(level, below);
            } else if (event.getDistance() >= 7.0F && canFall(level, below, state)) {
                queuePos(level, below);
                queueNeighbors(level, below);
            }
        }

        @SubscribeEvent
        public static void onLivingDeath(LivingDeathEvent event) {
            LivingEntity entity = event.getEntity();
            if (!(entity.level() instanceof ServerLevel)) return;
            Entity attacker = event.getSource().getEntity();
            if (attacker != null) {
                Vec3 push = entity.position().subtract(attacker.position());
                double len = Math.max(0.1D, Math.hypot(push.x, push.z));
                entity.setDeltaMovement(
                    (push.x / len) * 0.55D,
                    0.38D,
                    (push.z / len) * 0.55D
                );
                entity.hurtMarked = true;
            }
        }

        @SubscribeEvent
        public static void onLevelTick(TickEvent.LevelTickEvent event) {
            if (event.phase != TickEvent.Phase.END) return;
            if (!(event.level instanceof ServerLevel level)) return;
            ResourceKey<Level> dim = level.dimension();
            ArrayDeque<BlockPos> queue = QUEUES.get(dim);
            Set<BlockPos> set = QUEUED_SET.get(dim);
            if (queue == null || queue.isEmpty()) return;

            int fallen = 0;
            int checks = 0;
            while (!queue.isEmpty() && fallen < 24 && checks < 96) {
                BlockPos pos = queue.pollFirst();
                set.remove(pos);
                checks++;
                if (!level.isLoaded(pos)) continue;
                BlockState state = level.getBlockState(pos);
                if (!canFall(level, pos, state)) continue;
                if (!hasSupport(level, pos, state)) {
                    FallingBlockEntity falling = FallingBlockEntity.fall(level, pos, state);
                    falling.setHurtsEntities(1.5F, 20);
                    falling.dropItem = true;
                    spawnDebris(level, pos, state, 2, 0.14D);
                    queueNeighbors(level, pos);
                    fallen++;
                }
            }
        }

        @SubscribeEvent
        public static void onLevelUnload(LevelEvent.Unload event) {
            if (event.getLevel() instanceof ServerLevel level) {
                QUEUES.remove(level.dimension());
                QUEUED_SET.remove(level.dimension());
            }
        }

        private static void queuePos(ServerLevel level, BlockPos pos) {
            ResourceKey<Level> dim = level.dimension();
            ArrayDeque<BlockPos> queue = QUEUES.computeIfAbsent(dim, k -> new ArrayDeque<>());
            Set<BlockPos> set = QUEUED_SET.computeIfAbsent(dim, k -> new HashSet<>());
            BlockPos imm = pos.immutable();
            if (set.size() < 4000 && set.add(imm)) {
                queue.addLast(imm);
            }
        }

        private static void queueNeighbors(ServerLevel level, BlockPos center) {
            queuePos(level, center.above());
            queuePos(level, center.north());
            queuePos(level, center.south());
            queuePos(level, center.east());
            queuePos(level, center.west());
            BlockPos up = center.above();
            queuePos(level, up.north());
            queuePos(level, up.south());
            queuePos(level, up.east());
            queuePos(level, up.west());
        }

        private static boolean canFall(ServerLevel level, BlockPos pos, BlockState state) {
            if (state.isAir()) return false;
            if (!state.getFluidState().isEmpty()) return false;
            if (state.getDestroySpeed(level, pos) < 0) return false;
            if (level.getBlockEntity(pos) != null) return false;
            if (state.getCollisionShape(level, pos).isEmpty()) return false;
            return true;
        }

        private static boolean isFragile(BlockState state) {
            return state.is(Tags.Blocks.GLASS)
                || state.is(Tags.Blocks.GLASS_PANES)
                || state.is(BlockTags.ICE)
                || state.is(BlockTags.LEAVES)
                || state.is(BlockTags.SNOW);
        }

        private static int getStructuralRange(BlockState state) {
            if (state.is(Blocks.IRON_BLOCK) || state.is(Blocks.OBSIDIAN)) {
                return 3;
            }
            if (state.is(BlockTags.LOGS)
                || state.is(BlockTags.PLANKS)
                || state.is(BlockTags.STONE_BRICKS)
                || state.is(BlockTags.FENCES)
                || state.is(BlockTags.WALLS)
                || state.is(BlockTags.WOODEN_STAIRS)
                || state.is(BlockTags.WOODEN_SLABS)
                || state.is(Blocks.STONE)
                || state.is(Blocks.SMOOTH_STONE)
                || state.is(Blocks.BRICKS)) {
                return 2;
            }
            return 0;
        }

        private static boolean isSolidSupport(ServerLevel level, BlockPos pos) {
            BlockState s = level.getBlockState(pos);
            return !s.isAir() && s.getFluidState().isEmpty() && !s.getCollisionShape(level, pos).isEmpty();
        }

        private static boolean hasSupport(ServerLevel level, BlockPos start, BlockState state) {
            if (isSolidSupport(level, start.below())) {
                return true;
            }
            int maxRange = getStructuralRange(state);
            if (maxRange <= 0) {
                return false;
            }
            ArrayDeque<BlockPos> bfs = new ArrayDeque<>();
            Map<BlockPos, Integer> distMap = new HashMap<>();
            bfs.add(start);
            distMap.put(start, 0);
            Direction[] horiz = {Direction.NORTH, Direction.SOUTH, Direction.EAST, Direction.WEST};
            while (!bfs.isEmpty()) {
                BlockPos cur = bfs.pollFirst();
                int d = distMap.get(cur);
                if (d >= maxRange) continue;
                for (Direction dir : horiz) {
                    BlockPos next = cur.relative(dir);
                    if (distMap.containsKey(next)) continue;
                    if (!level.isLoaded(next)) return true;
                    BlockState ns = level.getBlockState(next);
                    if (ns.is(BlockTags.LEAVES) || !isSolidSupport(level, next)) continue;
                    if (isSolidSupport(level, next.below())) {
                        return true;
                    }
                    if (getStructuralRange(ns) > 0) {
                        distMap.put(next, d + 1);
                        bfs.addLast(next);
                    }
                }
            }
            return false;
        }

        private static void spawnDebris(ServerLevel level, BlockPos pos, BlockState state, int count, double power) {
            if (state.isAir() || state.getRenderShape() == RenderShape.INVISIBLE) return;
            if (level.getEntitiesOfClass(DebrisEntity.class, new AABB(pos).inflate(20.0D)).size() >= 110) return;
            for (int i = 0; i < count; i++) {
                double ox = pos.getX() + 0.2D + level.getRandom().nextDouble() * 0.6D;
                double oy = pos.getY() + 0.2D + level.getRandom().nextDouble() * 0.6D;
                double oz = pos.getZ() + 0.2D + level.getRandom().nextDouble() * 0.6D;
                float scale = 0.22F + level.getRandom().nextFloat() * 0.16F;
                DebrisEntity debris = new DebrisEntity(level, ox, oy, oz, state, scale);
                debris.setDeltaMovement(
                    (level.getRandom().nextDouble() - 0.5D) * power * 2.0D,
                    0.14D + level.getRandom().nextDouble() * power,
                    (level.getRandom().nextDouble() - 0.5D) * power * 2.0D
                );
                level.addFreshEntity(debris);
            }
        }
    }
}
